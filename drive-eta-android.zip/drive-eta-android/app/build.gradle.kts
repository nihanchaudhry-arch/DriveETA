plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nivaan.driveeta"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nivaan.driveeta"
        minSdk = 24
        targetSdk = 35
        // Each GitHub build gets a higher number, so updates install over the old app
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    // Same signing key every build, so updates install without uninstalling first
    signingConfigs {
        create("fixed") {
            storeFile = file("driveeta.jks")
            storePassword = "driveeta"
            keyAlias = "driveeta"
            keyPassword = "driveeta"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
