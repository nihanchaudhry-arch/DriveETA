package com.nivaan.driveeta

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

/**
 * Drive ETA — shows the app (assets/www/index.html) full screen and feeds it
 * positions straight from the car's GPS chip once per second.
 */
class MainActivity : Activity(), LocationListener {

    private lateinit var web: WebView
    private var locationManager: LocationManager? = null
    private var gpsRunning = false

    // Pages load from https://appassets.androidplatform.net so they count as a secure website.
    // (Restrict your Google Maps key to this address.)
    private val appUrl = "https://appassets.androidplatform.net/assets/www/index.html"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#0b0f14")
        window.navigationBarColor = Color.parseColor("#0b0f14")

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0b0f14"))
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true          // remembers your Google Maps key
            databaseEnabled = true
            setGeolocationEnabled(true)
            mediaPlaybackRequiresUserGesture = false
        }
        web.addJavascriptInterface(GpsBridge(), "AndroidGps")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            // Links to other sites (e.g. Google Cloud) open in the browser
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == "appassets.androidplatform.net") return false
                return try { startActivity(Intent(Intent.ACTION_VIEW, url)); true } catch (e: Exception) { true }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, true, false)
            }
        }

        web.loadUrl(appUrl)
        askPermissions()
    }

    // ---------------- Permissions ----------------
    private fun hasLocation() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val wanted = mutableListOf<String>()
        if (!hasLocation()) {
            wanted += Manifest.permission.ACCESS_FINE_LOCATION
            wanted += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) wanted += Manifest.permission.POST_NOTIFICATIONS

        if (wanted.isEmpty()) startGps() else requestPermissions(wanted.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasLocation()) startGps()
    }

    // ---------------- GPS ----------------
    @SuppressLint("MissingPermission")
    private fun startGps() {
        if (gpsRunning || !hasLocation()) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        locationManager = lm
        for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            if (!lm.allProviders.contains(provider)) continue
            try {
                lm.requestLocationUpdates(provider, 1000L, 0f, this, Looper.getMainLooper())
                gpsRunning = true
            } catch (e: Exception) { /* provider not available on this unit */ }
        }
        try {
            (lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER))?.let { send(it) }
        } catch (e: Exception) { }

        // Foreground service so tracking continues while you use other apps
        try {
            val i = Intent(this, TrackingService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Exception) { }
    }

    private fun stopGps() {
        try { locationManager?.removeUpdates(this) } catch (e: Exception) { }
        gpsRunning = false
        try { stopService(Intent(this, TrackingService::class.java)) } catch (e: Exception) { }
    }

    private fun send(l: Location) {
        // Ignore rough network fixes once real GPS is working
        val acc = if (l.hasAccuracy()) l.accuracy.toDouble() else 50.0
        val speed = if (l.hasSpeed()) l.speed.toString() else "null"
        val js = "window.__nativeFix&&window.__nativeFix(${l.latitude},${l.longitude},$acc,$speed,${System.currentTimeMillis()})"
        web.post { web.evaluateJavascript(js, null) }
    }

    override fun onLocationChanged(location: Location) = send(location)

    // Needed on older Android versions, which call these and crash if they're missing
    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    /** Lets the page ask the app to (re)start GPS. */
    inner class GpsBridge {
        @JavascriptInterface
        fun start() { runOnUiThread { if (hasLocation()) startGps() else askPermissions() } }
    }

    // ---------------- Lifecycle ----------------
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else moveTaskToBack(true)   // keep running, don't close mid-trip
    }

    override fun onDestroy() {
        stopGps()
        web.destroy()
        super.onDestroy()
    }
}
