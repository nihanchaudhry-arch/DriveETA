# Drive ETA (Android)

Live time & distance to destination, calculated from your speed over the last 100 m.

- `app/src/main/assets/www/index.html` – the app screen (HTML/JS)
- `app/src/main/java/.../MainActivity.kt` – full-screen app, car GPS -> screen, keeps screen on
- `app/src/main/java/.../TrackingService.kt` – keeps GPS running while other apps are open
- `.github/workflows/build.yml` – copy this to the repo root `.github/workflows/build.yml`;
  GitHub then builds `DriveETA.apk` and puts it under Releases.

Google Maps key: restrict it (Websites) to `https://appassets.androidplatform.net/*`
